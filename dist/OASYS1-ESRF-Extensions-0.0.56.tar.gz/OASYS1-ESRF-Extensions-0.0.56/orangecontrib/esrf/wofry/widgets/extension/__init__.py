# Category description for the widget registry

NAME = "Wofry ESRF Extension"

DESCRIPTION = "Widgets for Wofry"

BACKGROUND = "#ada8a8"

ICON = "icons/esrf2.png"

PRIORITY = 14
