# Category description for the widget registry

NAME = "XOPPY ESRF Extension"

DESCRIPTION = "Widgets for XOPPY"

BACKGROUND = "#eaaB60"

ICON = "icons/esrf2.png"

PRIORITY = 2003
