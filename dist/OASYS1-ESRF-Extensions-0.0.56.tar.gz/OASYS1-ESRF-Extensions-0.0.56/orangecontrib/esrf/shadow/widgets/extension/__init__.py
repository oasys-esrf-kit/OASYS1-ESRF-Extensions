
# Category description for the widget registry

NAME = "ShadowOui ESRF Extension"

DESCRIPTION = "Widgets for ShadowOui"

BACKGROUND = "#0099cc"

ICON = "icons/esrf2.png"

PRIORITY = 130
