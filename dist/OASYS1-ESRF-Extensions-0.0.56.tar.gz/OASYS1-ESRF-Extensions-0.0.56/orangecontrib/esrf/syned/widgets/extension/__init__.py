
# Category description for the widget registry

NAME = "Syned ESRF Extension"

DESCRIPTION = "Widgets for Syned ESRF Extension"

BACKGROUND = "#deb589"

ICON = "icons/esrf2.png"

PRIORITY = 10.5
