# Category description for the widget registry

NAME = "SRW ESRF Extension"

DESCRIPTION = "Widgets for SRW"

BACKGROUND = "#969fde"

ICON = "icons/esrf2.png"

PRIORITY = 204
