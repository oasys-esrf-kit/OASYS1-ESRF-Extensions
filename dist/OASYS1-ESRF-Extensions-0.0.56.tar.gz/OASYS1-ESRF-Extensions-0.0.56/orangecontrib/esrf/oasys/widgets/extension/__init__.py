
# Category description for the widget registry

NAME = "Oasys ESRF Extension"

DESCRIPTION = "Widgets for Oasys"

BACKGROUND = "#fa982f"

ICON = "icons/esrf2.png"

PRIORITY = 4.90
